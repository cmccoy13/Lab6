package com.example.cmmccoy.lab4

data class PlayerResponse(
        val name : String = "",
        val num : Int = 0,
        val position : String = "",
        val captain : Boolean = false)

fun PlayerResponse.mapToPlayer() = PlayerItem(name, num, position, captain)

data class PlayerItem(
        val name : String,
        val num : Int,
        val position : String,
        val captain : Boolean)