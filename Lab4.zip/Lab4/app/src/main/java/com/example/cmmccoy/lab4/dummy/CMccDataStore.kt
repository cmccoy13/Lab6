package com.example.cmmccoy.lab4.dummy

import java.util.ArrayList
import java.util.HashMap

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 *
 * TODO: Replace all uses of this class before publishing your app.
 */
object CMccDataStore {

    /**
     * An array of sample (dummy) items.
     */
    val ITEMS: MutableList<playerItem> = ArrayList()

    /**
     * A map of sample (dummy) items, by ID.
     */
    val ITEM_MAP: MutableMap<String, playerItem> = HashMap()

    init {

    }

    private fun addItem(item: playerItem) {
        ITEMS.add(item)
        ITEM_MAP.put(item.name, item)
    }

    fun editPlayer(oldName: String, newName: String, num: Int, pos: String, captain: Boolean){
        var player = getPlayer(oldName)
        player.name = newName
        player.num = num
        player.pos = pos
        player.captain = captain

        ITEM_MAP.remove(oldName)
        ITEM_MAP.put(newName, player)
    }

    fun createPlayer(name: String, num: Int, pos: String, captain: Boolean){
        val player = playerItem(name, num, pos, captain)
        addItem(player)
    }

    public fun removePlayer(name: String){
        ITEMS.remove(ITEM_MAP.get(name))
        ITEM_MAP.remove(name)
    }

    public fun getPlayer(name: String) : playerItem{
        return ITEMS.get(ITEMS.indexOf(ITEM_MAP.get(name)))
    }

    /**
     * A dummy item representing a piece of content.
     */
    data class playerItem(var name: String, var num: Int, var pos: String, var captain: Boolean) {
        override fun toString(): String = name
    }
}
