package com.example.cmmccoy.lab4

import android.content.Intent
import android.os.Bundle
import android.provider.DocumentsContract
import android.support.v4.app.NavUtils
import android.support.v7.app.AppCompatActivity
import com.example.cmmccoy.lab4.dummy.CMccDataStore
import kotlinx.android.synthetic.main.create_player.*
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.ValueEventListener
import org.w3c.dom.Document


class PlayerCreateActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.create_player)

        playerSubmit.setOnClickListener{
            val name = playerName.text.toString()
            //val num = playerNum.text
            val num = Integer.parseInt(playerNum.text.toString())
            val pos = playerPosition.text.toString()
            val captain = playerCaptain.isChecked

            CMccDataStore.createPlayer(name, num, pos, captain)


            // Write a message to the database
            val database = FirebaseDatabase.getInstance()
            database.setPersistenceEnabled(true)
            val testPlayer = database.getReference("TestPlayer1")
            testPlayer.child("Name").setValue("New Name")

            val playerRef = database.getReference("Players")

            // Create a new instance to add
            val newPlayer = CMccDataStore.getPlayer(name)
            playerRef.child(name).setValue(newPlayer)

            NavUtils.navigateUpTo(this, Intent(this, ItemListActivity::class.java))
            true
        }

        if (savedInstanceState == null) {
            var pName = intent.getStringExtra("Player Name")
            if (pName != null) {
                val player = CMccDataStore.getPlayer(pName)

                playerName.setText(player.name)
                playerNum.setText(player.num.toString())
                playerPosition.setText(player.pos)
                playerCaptain.isChecked = player.captain
                playerSubmit.setText("Update")

                playerSubmit.setOnClickListener{
                    val name = playerName.text.toString()
                    val num = Integer.parseInt(playerNum.text.toString())
                    val pos = playerPosition.text.toString()
                    val captain = playerCaptain.isChecked

                    CMccDataStore.editPlayer(pName, name, num, pos, captain)
                    NavUtils.navigateUpTo(this, Intent(this, ItemListActivity::class.java))
                    true
                }
            }

            //playerName.setText(pName)
        }
    }
}